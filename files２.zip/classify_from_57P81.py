#!/usr/bin/env python3
"""
PT国家試験問題 分野分類スクリプト
Claude Code用 - 57P-81から開始

使用方法:
  python3 classify_from_57P81.py [宮﨑.jsonのパス]
"""

import json
import re
import sys

def sort_key(q):
    m = re.match(r'(\d+)([APM])-(\d+)', q['id'])
    if m:
        return (int(m.group(1)), {'A':0,'P':1}.get(m.group(2),9), int(m.group(3)))
    return (0,9,0)

def main():
    json_path = sys.argv[1] if len(sys.argv) > 1 else '宮﨑.json'
    
    with open(json_path, encoding='utf-8') as f:
        data = json.load(f)
    
    data_sorted = sorted(data, key=sort_key)
    
    # 確認
    print(f"総問題数: {len(data_sorted)}")
    print(f"index 1379: {data_sorted[1379]['id']}  (このセッションで処理済み)")
    print(f"index 1380: {data_sorted[1380]['id']}  (次回開始ポイント)")
    print()
    
    # 残り問題一覧
    remaining = data_sorted[1380:]
    exams = {}
    for q in remaining:
        m = re.match(r'(\d+)([APM])-(\d+)', q['id'])
        if m:
            key = f"{m.group(1)}{m.group(2)}"
            exams[key] = exams.get(key, 0) + 1
    print("残り問題:")
    for k, v in sorted(exams.items()):
        print(f"  {k}: {v}問")
    print(f"合計: {len(remaining)}問")
    
    return data_sorted

if __name__ == '__main__':
    data_sorted = main()
